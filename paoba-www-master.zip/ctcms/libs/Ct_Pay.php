<?php
define('CT_Rmb_To_Cion',10);  //1元=多少个金币   
define('CT_Vip1_Rmb',1);  //1天VIP=多少RMB  
define('CT_Vip2_Rmb',10);  //30天VIP=多少RMB  
define('CT_Vip3_Rmb',50);  //180天VIP=多少RMB  
define('CT_Vip4_Rmb',90);  //365天VIP=多少RMB  
define('CT_Pay',1);  //支付宝开关    
define('CT_Pay_ID','');  //合作者ID    
define('CT_Pay_Key','');  //安全验效码KEY