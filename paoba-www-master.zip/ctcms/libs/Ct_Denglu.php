<?php
define('Qq_Log',0);
define('Qq_Appid','');
define('Qq_Appkey','');
define('Wx_Log',0);
define('Wx_Appid','');
define('Wx_Appkey','');