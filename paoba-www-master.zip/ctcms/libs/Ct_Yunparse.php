<?php
define('REFERER_URL', '');  //防盗链域名  
define('USER_ID', '800000000');//解析UID  
define('USER_TOKEN', 'xxxxxxxxxxx');//解析TOKEN  
define('VOD_HD', '2'); //默认清晰度  
define('VOD_API', '1');//解析默认线路  
define('VOD_JM', '0');//解析是否加密  
define('VOD_TIME', '1800');//解析加密有效期
define('VOD_API_URL', ''); //其他解析线路