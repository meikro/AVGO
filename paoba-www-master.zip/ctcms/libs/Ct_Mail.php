<?php
define('CT_Smtphost','smtp.126.com');  //SMTP服务器    
define('CT_Smtpport','25');  ////SMTP端口    
define('CT_Smtpuser','ctcms@126.com');  //SMTP帐号  
define('CT_Smtppass','123456');  //SMTP密码  
define('CT_Smtpmail','ctcms@126.com');  //发送EMAIL  
define('CT_Smtpname','赤兔CMS');  //发送者名称