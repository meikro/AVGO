<?php
define('CT_App_Ver','1.0'); //APP版本号  
define('CT_App_Cyid',''); //APP畅言APPID  
define('CT_App_Cykey',''); //APP畅言APPKEY  
define('CT_App_Kalink','');  //点卡购买地址  
define('CT_App_Uplink','http://demo.vod.ctcms.cn/index.php/app/share/down');  //APP升级更新地址  
define('CT_App_Jxurl','');  //APP解析地址  
define('CT_App_Sktime','30');  //收费视频试看分钟  
define('CT_App_Paytype','alipay|wxpay');  //APP付款方式  