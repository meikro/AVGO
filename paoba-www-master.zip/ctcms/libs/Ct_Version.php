<?php
//程序版本
define("Ct_Upurl","http://api.ctcms.cn/admin/");
define("Ct_Version","2.0.9");
define("Ct_Code","utf8");