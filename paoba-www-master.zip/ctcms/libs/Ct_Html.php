<?php
define('Html_Off',0);  //生成开关
define('Html_Play_Off',0);  //播放页生成开关
define('Html_Dir','');  //生成目录
define('Html_Url','');  //生成目录访问地址
define('Html_Index','index.html');  //主页生成地址
define('Html_List','list/[id]_[page].html');  //列表页生成地址
define('Html_Show','show/[id].html');  //内容页生成地址
define('Html_Play','play/[id]/[zu]/[ji].html');  //播放页生成地址
define('Html_Topic','topic/[page].html');  //专题列表页生成地址
define('Html_Topic_Show','topic/show/[id].html');  //专题内容页生成地址
define('Html_News_List','news/list/[id]_[page].html');  //文章列表页生成地址
define('Html_News_Show','news/show/[id]_[page].html');  //文章内容页生成地址