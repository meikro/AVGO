<?php
/**
 * @Ctcms open source management system
 * @copyright 2008-2019 ctcms.cn. All rights reserved.
 * @Author:Cheng Kai Jie
 * @Dtime:2015-12-11
 */
defined('BASEPATH') OR exit('No direct script access allowed');
class Index extends Ctcms_Controller {
	function __construct(){
	    parent::__construct();
		//加载后台模型
		$this->load->model('admin');
        //当前模版
		$this->load->get_templates('admin');
		//判断是否登陆
		$this->admin->login();
	}

	public function index()
	{
        $where = array('id'=>$_SESSION['admin_id']);
		$data['admin']=$this->csdb->get_row('admin','*',$where);
		$this->load->view('head.tpl',$data);
		$this->load->view('index.tpl');
	}
}