<!DOCTYPE html>
<html>
<head>
<title><?php echo Web_Name;?></title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'>
</head>
<body>
<center>
<br>
<h4>友情提示</h4>
<p>本站不支持电脑观看，请用手机访问。</p>
<p>关注公众号：<a href="<?php echo Weixin_Url;?>"><?php echo Weixin;?></a></p>
</center>
</body>
</html>