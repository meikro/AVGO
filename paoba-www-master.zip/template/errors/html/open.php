<!DOCTYPE html>
<html>
<head>
<title><?php echo Web_Name;?></title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'>
</head>
<body>
<center>
<br>
<h4>友情提示</h4>
<p><?php echo Web_Onneir;?></p>
</center>
</body>
</html>