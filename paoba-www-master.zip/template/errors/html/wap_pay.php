<!DOCTYPE html>
<html>
<head>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'>
</head>
<body>
<center>
<br><h4>{title}</h4>
<a href="{url}">点击确定购买观看</a><br><br>
<a href="{path}">返回首页</a>
</center>
</body>
</html>