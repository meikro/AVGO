<?php
/*
  Yun Parse 云解析,QQ:157503886
  请在下面地址查询统计情况。
  http://120.27.155.106/login
*/
defined('FCPATH') OR exit('No direct script access allowed');
//加载配置文件
require_once FCPATH.'../../../ctcms/libs/Ct_Yunparse.php';
//错误提示
error_reporting(0);
//默认时区
date_default_timezone_set("Asia/Shanghai");
//强制编码
header('Content-type:text/html;charset=utf-8');
//API地址，不能修改
define('API_URL', get_api());
//网站的插件目录
define('WEB_PATH', web_path());
//插件版本号
define('YUN_VER', '2.0.0');
//判断手机客户端
$wap = preg_match("/(iPhone|iPad|iPod|Linux|Android)/i", strtoupper($_SERVER['HTTP_USER_AGENT']));
//获取网站运行目录
function web_path(){
	$uri = 'http://yunparse'.$_SERVER['REQUEST_URI'];
	$arr = parse_url($uri);
	return str_replace(SELF,'',$arr['path']);
}
//获取API地址
function get_api($n=0){
	if(VOD_API == '1'){
		$api = get_key('AOl4Hr6Yr0VpExMpv9ARmVJbK3Dsl_eR8hfYS3gYeHkMCFRe1qfw6QWyYwPaY1v1ZxyoKXPF','D','YunParse');
	}elseif(VOD_API == '2'){
		$api = get_key('Bu57G7PPrRFpExMpv9ARmVJbKHDsl_eR8hfYS3gYeHkMC1Re1qfw6QWyYwPaY1v1ZxyoKX7B','D','YunParse');
	}elseif(VOD_API == '3'){
		$api = get_key('Duh5SrObr0JpExMpv9ARmVJbKXDsl_eR8hfYS3gYeHkMClRe1qfw6QWyYwPaY1v1ZxyoKX/E','D','YunParse');
	}elseif(VOD_API == '4'){
		$api = get_key('U_suT_TIrBxpExMpv9ARmVJbLnDsl_eR8hfYS3gYeHkMDVRe1qfw6QWyYwPaY1v1ZxyoLnfD','D','YunParse');
	}else{
		$api = get_key('VOFyTbLJqxNpExMpv9ARmVJbZCTsnvyTtlrUSTpWaWBLGRJek6O08AnyNxrTb1D1bBCiLw','D','YunParse');
	}
	if($n==1){
		$arrs = array('api.php','apia.php','apib.php','apic.php','apid.php');
		$api = str_replace($arrs, 'api_data.php', $api);
	}
	return $api;
}
//判断防盗链域名
function is_referer(){
	//没有设置防盗链
    if(REFERER_URL=='' || (empty($_SERVER['HTTP_REFERER']) && REFERER_ID==1)) return true; 
	//获取来路域名
	$uriarr = parse_url($_SERVER['HTTP_REFERER']);
	$host = $uriarr['host'];
	$ymarr = explode("|",REFERER_URL);
    if(in_array($host,$ymarr)){
    	return true;
    }
    return false;
}
//获取远程内容
function get_url($url,$post='',$head='') {
	$url = $url.'&ref='.rawurlencode($_SERVER['HTTP_REFERER']).'&ver='.YUN_VER;
    // 判断是否支持CURL
    if (empty($post) && empty($head) && (!function_exists('curl_init') || !function_exists('curl_exec'))) {
		$data = file_get_contents($url);
	}else{
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		curl_setopt($curl, CURLOPT_REFERER, "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
		curl_setopt($curl, CURLOPT_AUTOREFERER, 1);
		curl_setopt($curl, CURLOPT_TIMEOUT, 15);
		curl_setopt($curl, CURLOPT_HEADER, 0);
		if(!empty($post)){
		   curl_setopt($curl, CURLOPT_POST, 1);
		   curl_setopt($curl, CURLOPT_POSTFIELDS, $post);
		}
		if(!empty($head)){
		   curl_setopt($curl, CURLOPT_HTTPHEADER, $head);
		}
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); 
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); 
		$data = curl_exec($curl);
		curl_close($curl);
	}
    return $data;
}
//字符加密、解密
function get_key($string,$operation='E',$key=''){
	if(empty($string)) return '';
	if($operation=='E'){$string.='-time-'.(time()+1800);}if($key==''){$key=md5(USER_TOKEN);}$key_length=strlen($key);$string=$operation=='D'?base64_decode(str_replace('-','/',str_replace('_','+',$string))):substr(md5($string.$key),0,8).$string;$string_length=strlen($string);$rndkey=$box=array();$result='';
	for($i=0;$i<=255;$i++){$rndkey[$i]=ord($key[$i%$key_length]);$box[$i]=$i;}
	for($j=$i=0;$i<256;$i++){$j=($j+$box[$i]+$rndkey[$i])%256;$tmp=$box[$i];$box[$i]=$box[$j];$box[$j]=$tmp;}
	for($a=$j=$i=0;$i<$string_length;$i++){$a=($a+1)%256;$j=($j+$box[$a])%256;$tmp=$box[$a];$box[$a]=$box[$j];$box[$j]=$tmp;$result.=chr(ord($string[$i])^($box[($box[$a]+$box[$j])%256]));}
	if($operation=='D'){if(substr($result,0,8)==substr(md5(substr($result,8).$key),0,8)){$str = substr($result,8);$arr = explode("-time-",$str);if((empty($arr[1]) || $arr[1]<time()) && $key!='YunParse') return '';return $arr[0];}else{return '';}}else{return str_replace('+','_',str_replace('=','',base64_encode($result)));}
}
//json输出
function get_json($arr=array()){
	$json = json_encode($arr);
	header('Content-Type: text/json; charset=utf-8');
	exit($json);
}
//数组转XML
function get_xml($str){
	global $hd,$url;
	$xml='<ckplayer><flashvars>{lv->0}{v->80}{e->0}{p->1}{q->start}{h->3}{f->'.WEB_PATH.'api.php?url='.$url.'&amp;[$pat]}{a->hd='.$hd.'}{defa->hd=1|hd=2|hd=3|hd=4}{deft->标清|高清|超清|原画}</flashvars>
	<video>';
	$arr = $str['url'];
	if(is_array($arr)){
	     for($i=0;$i<count($arr);$i++){
			 $xml.='<file><![CDATA['.$arr[$i]['purl'].']]></file>';
			 if(isset($arr[$i]['size'])) $xml.='<size>'.$arr[$i]['size'].'</size>';
			 if(isset($arr[$i]['sec'])) $xml.='<seconds>'.$arr[$i]['sec'].'</seconds>';     
	     }
	}else{
		 $xml.='<file><![CDATA['.$str['url'].']]></file>';
		 if(isset($str['size'])) $xml.='<size>'.$str['size'].'</size>';
		 if(isset($str['sec'])) $xml.='<seconds>'.$str['sec'].'</seconds>';  
	}
	$xml.='</video></ckplayer>';
	$xml='<?xml version="1.0" encoding="utf-8"?>'.$xml;
	header('Content-type:text/xml;charset=utf-8');
	echo $xml;exit;
}
//根据来源替换播放IP
function get_new_arr($arr = array()){
	//乐视
	if($arr['ext']=='m3u8' && strpos($arr['url'], '&splatid=602') !== false){
		$head = array('CLIENT-IP:'.$_SERVER["REMOTE_ADDR"],'X-FORWARDED-FOR:'.$_SERVER["REMOTE_ADDR"]);
		$json2 = get_url($arr['url'].'&expect=3&format=1','',$head);
		$arr2 = json_decode($json2,1);
		for($i=0;$i<count($arr2['nodelist']);$i++){
			$arr['url'] = $arr2['nodelist'][$i]['location'];
			if(strpos($arr['url'], ':110/') === false){
				break;
			}
		}
	}
	//奇艺
	$ip = empty($_GET['ip']) ? $_POST['ip'] : $_GET['ip'];
	if(!preg_match("/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/",$ip)){
		$ip = '';
	}
	if($arr['type'] == 'qiyi' && !empty($ip)){
		$ip = 'http://'.$ip.'/';
		if(is_array($arr['url'])){
			foreach($arr['url'] as $k=>$v){
				$arr['url'][$k]['purl'] = preg_replace("/http\:\/\/[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\//",$ip,$arr['url'][$k]['purl']);
			}
		}else{
			if($arr['ext'] == 'm3u8_list') $arr['url'] = base64_decode($arr['url']);
			$arr['url'] = preg_replace("/http\:\/\/[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\//",$ip,$arr['url']);
			if($arr['ext'] == 'm3u8_list') $arr['url'] = base64_encode($arr['url']);
		}
	}
	return $arr;
}
//解密函数
function sys_auth($string){ 
	$string = str_replace('-','+',$string);
	$key = md5(USER_TOKEN);
	$keya = md5(substr($key, 0, 16));     
	$keyb = md5(substr($key, 16, 16));     
	$keyc = substr($string, 0, 4); 
	$cryptkey = $keya.md5($keya.$keyc);   
	$key_length = strlen($cryptkey);
	$string = base64_decode(substr($string, 4));   
	$string_length = strlen($string);   
	$result = '';   
	$box = range(0, 255);   
	$rndkey = array();     
	for($i = 0; $i <= 255; $i++) {   
		$rndkey[$i] = ord($cryptkey[$i % $key_length]);   
	}     
	for($j = $i = 0; $i < 256; $i++) {   
		$j = ($j + $box[$i] + $rndkey[$i]) % 256;   
		$tmp = $box[$i];   
		$box[$i] = $box[$j];   
		$box[$j] = $tmp;   
	}   
	for($a = $j = $i = 0; $i < $string_length; $i++) {   
		$a = ($a + 1) % 256;   
		$j = ($j + $box[$a]) % 256;   
		$tmp = $box[$a];   
		$box[$a] = $box[$j];   
		$box[$j] = $tmp;   
		$result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));   
	}      
	if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {   
		return substr($result, 26);   
	} else {   
		return '';   
	}   
}